package com.capstone.fintrack.pages;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.capstone.fintrack.todelete.models.Account;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
        mv = {1, 6, 0},
        k = 1,
        d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0013B\u001d\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\nH\u0016J\u0018\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\nH\u0016J\u0018\u0010\u000f\u001a\u00020\u00022\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\nH\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0014"},
        d2 = {"Lcom/capstone/fintrack/todelete/ui/home/HomeAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/capstone/fintrack/todelete/ui/home/HomeAdapter$ViewHolder;", "context", "Landroid/content/Context;", "mList", "", "Lcom/capstone/fintrack/todelete/models/Account;", "(Landroid/content/Context;Ljava/util/List;)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "ViewHolder", "app_debug"}
)
public final class HomeAdapter extends RecyclerView.Adapter {
    private Context context;
    private final List mList;

    @NotNull
    public ViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        View view = LayoutInflater.from(parent.getContext()).inflate(2131492931, parent, false);
        Intrinsics.checkNotNullExpressionValue(view, "view");
        return new ViewHolder(view);
    }

    // $FF: synthetic method
    // $FF: bridge method
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup var1, int var2) {
        return (RecyclerView.ViewHolder)this.onCreateViewHolder(var1, var2);
    }

    public void onBindViewHolder(@NotNull ViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        Account item = (Account)this.mList.get(position);
        holder.getName().setText((CharSequence)item.getName());
        holder.getIncome().setText((CharSequence)String.valueOf(item.getIncome()));
        holder.getExpense().setText((CharSequence)String.valueOf(item.getExpense()));
        holder.getBalance().setText((CharSequence)String.valueOf(item.getBalance()));
    }

    // $FF: synthetic method
    // $FF: bridge method
    public void onBindViewHolder(RecyclerView.ViewHolder var1, int var2) {
        this.onBindViewHolder((ViewHolder)var1, var2);
    }

    public int getItemCount() {
        return this.mList.size();
    }

    public HomeAdapter(@Nullable Context context, @NotNull List mList) {
        Intrinsics.checkNotNullParameter(mList, "mList");
        super();
        this.context = context;
        this.mList = mList;
    }

    @Metadata(
            mv = {1, 6, 0},
            k = 1,
            d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\bR\u0011\u0010\u000b\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\bR\u0011\u0010\r\u001a\u00020\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0011\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\b¨\u0006\u0013"},
            d2 = {"Lcom/capstone/fintrack/todelete/ui/home/HomeAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "ItemView", "Landroid/view/View;", "(Landroid/view/View;)V", "balance", "Landroid/widget/TextView;", "getBalance", "()Landroid/widget/TextView;", "expense", "getExpense", "income", "getIncome", "item", "Landroid/widget/LinearLayout;", "getItem", "()Landroid/widget/LinearLayout;", "name", "getName", "app_debug"}
    )
    public static final class ViewHolder extends RecyclerView.ViewHolder {
        @NotNull
        private final TextView income;
        @NotNull
        private final TextView expense;
        @NotNull
        private final TextView balance;
        @NotNull
        private final TextView name;
        @NotNull
        private final LinearLayout item;

        @NotNull
        public final TextView getIncome() {
            return this.income;
        }

        @NotNull
        public final TextView getExpense() {
            return this.expense;
        }

        @NotNull
        public final TextView getBalance() {
            return this.balance;
        }

        @NotNull
        public final TextView getName() {
            return this.name;
        }

        @NotNull
        public final LinearLayout getItem() {
            return this.item;
        }

        public ViewHolder(@NotNull View ItemView) {
            Intrinsics.checkNotNullParameter(ItemView, "ItemView");
            super(ItemView);
            View var10001 = this.itemView.findViewById(2131296807);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvIncome)");
            this.income = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296805);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvExpense)");
            this.expense = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296795);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvBalance)");
            this.balance = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296809);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvName)");
            this.name = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296538);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.llItem)");
            this.item = (LinearLayout)var10001;
        }
    }
}
