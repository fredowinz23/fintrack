package com.capstone.fintrack.pages;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatDelegate;
import com.capstone.fintrack.todelete.MainActivity;
import com.capstone.fintrack.todelete.api.UserSession;
import com.capstone.fintrack.todelete.api.ApiInterface;
import com.capstone.fintrack.api.RetrofitClient;
import com.capstone.fintrack.databinding.ActivityLoginBinding;
import com.capstone.fintrack.todelete.auth.LoginInfo;
import com.capstone.fintrack.todelete.debug.HostUrlActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private ActivityLoginBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (binding.etUsername.getText().toString().isEmpty() || binding.etPassword.getText().toString().isEmpty()) {
                    Toast.makeText(
                            LoginActivity.this,
                            "Username and password must not be empty",
                            Toast.LENGTH_LONG
                    ).show();
                } else {
                    postLoginData(binding.etUsername.getText().toString(),
                            binding.etPassword.getText().toString());
                }
            }
        });
    }

    private void postLoginData(String username, String password) {
        RetrofitClient retrofit = RetrofitClient.getInstance(LoginActivity.this);
        ApiInterface retrofitAPI = retrofit.create(ApiInterface.class);
        binding.btnLogin.setVisibility(View.GONE);
        binding.progressBar.setVisibility(View.VISIBLE);
        LoginInfo loginModal = new LoginInfo(username, password);
        Call<LoginInfo> call = retrofitAPI.loginUser(loginModal);
        call.enqueue(new Callback<LoginInfo>() {
            @Override
            public void onResponse(Call<LoginInfo> call, Response<LoginInfo> response) {
                LoginInfo responseFromAPI = response.body();
                if (responseFromAPI != null && !responseFromAPI.getProfile().getUsername().isEmpty()) {
                    UserSession userSession = new UserSession(LoginActivity.this);
                    userSession.edit.putString("username", responseFromAPI.getProfile().getUsername());
                    userSession.edit.apply();
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    finish();
                } else {
                    binding.progressBar.setVisibility(View.GONE);
                    binding.btnLogin.setVisibility(View.VISIBLE);
                    Toast.makeText(
                            LoginActivity.this,
                            "Username and Password not matched",
                            Toast.LENGTH_LONG
                    ).show();
                }
            }

            @Override
            public void onFailure(Call<LoginInfo> call, Throwable t) {
                Toast.makeText(
                        LoginActivity.this,
                        t.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
                binding.progressBar.setVisibility(View.GONE);
                binding.btnLogin.setVisibility(View.VISIBLE);
                Log.e("Login Error", t.getMessage());
            }
        });
    }
}


