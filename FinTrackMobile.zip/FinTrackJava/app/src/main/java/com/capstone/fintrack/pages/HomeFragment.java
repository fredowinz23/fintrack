package com.capstone.fintrack.pages;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.capstone.fintrack.databinding.FragmentHomeBinding;
import com.capstone.fintrack.todelete.api.ApiInterface;
import com.capstone.fintrack.todelete.api.RetrofitClient;
import com.capstone.fintrack.todelete.api.UserSession;
import com.capstone.fintrack.todelete.request.HomeDataRequest;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

@Metadata(
        mv = {1, 6, 0},
        k = 1,
        d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\b\u0010\b\u001a\u00020\tH\u0002J$\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\r2\b\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0016J\b\u0010\u0012\u001a\u00020\tH\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\u00020\u00048BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0013"},
        d2 = {"Lcom/capstone/fintrack/todelete/ui/home/HomeFragment;", "Landroidx/fragment/app/Fragment;", "()V", "_binding", "Lcom/capstone/fintrack/databinding/FragmentHomeBinding;", "binding", "getBinding", "()Lcom/capstone/fintrack/databinding/FragmentHomeBinding;", "getHomeData", "", "onCreateView", "Landroid/view/View;", "inflater", "Landroid/view/LayoutInflater;", "container", "Landroid/view/ViewGroup;", "savedInstanceState", "Landroid/os/Bundle;", "onDestroyView", "app_debug"}
)
public final class HomeFragment extends Fragment {
    private FragmentHomeBinding _binding;

    private final FragmentHomeBinding getBinding() {
        FragmentHomeBinding var10000 = this._binding;
        Intrinsics.checkNotNull(var10000);
        return var10000;
    }

    @NotNull
    public View onCreateView(@NotNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Intrinsics.checkNotNullParameter(inflater, "inflater");
        this._binding = FragmentHomeBinding.inflate(inflater, container, false);
        ConstraintLayout var10000 = this.getBinding().getRoot();
        Intrinsics.checkNotNullExpressionValue(var10000, "binding.root");
        View root = (View)var10000;
        this.getHomeData();
        return root;
    }

    private final void getHomeData() {
        Retrofit retrofit = RetrofitClient.INSTANCE.getInstance(this.getContext());
        ApiInterface retrofitAPI = (ApiInterface)retrofit.create(ApiInterface.class);
        UserSession userSession = new UserSession(this.getContext());
        String var10002 = userSession.getUsername();
        Intrinsics.checkNotNull(var10002);
        HomeDataRequest dataRequest = new HomeDataRequest(var10002, (String)null, 0.0F, (List)null, 14, (DefaultConstructorMarker)null);
        Call call = retrofitAPI.getHomeData(dataRequest);
        call.enqueue((Callback)(new Callback() {
            public void onResponse(@NotNull Call call, @NotNull Response response) {
                Intrinsics.checkNotNullParameter(call, "call");
                Intrinsics.checkNotNullParameter(response, "response");
                ProgressBar var10000 = HomeFragment.this.getBinding().progressBar;
                Intrinsics.checkNotNullExpressionValue(var10000, "binding.progressBar");
                var10000.setVisibility(8);
                HomeDataRequest responseFromAPI = (HomeDataRequest)response.body();
                GridLayoutManager groupLinear = new GridLayoutManager(HomeFragment.this.getContext(), 2);
                RecyclerView var7 = HomeFragment.this.getBinding().rvList;
                Intrinsics.checkNotNullExpressionValue(var7, "binding.rvList");
                var7.setLayoutManager((RecyclerView.LayoutManager)groupLinear);
                List var8 = responseFromAPI != null ? responseFromAPI.getAccount_list() : null;
                Intrinsics.checkNotNull(var8);
                List data = var8;
                TextView var9 = HomeFragment.this.getBinding().tvBudget;
                Intrinsics.checkNotNullExpressionValue(var9, "binding.tvBudget");
                var9.setText((CharSequence)String.valueOf(responseFromAPI.getBudget()));
                HomeAdapter adapter = new HomeAdapter(HomeFragment.this.getContext(), data);
                var7 = HomeFragment.this.getBinding().rvList;
                Intrinsics.checkNotNullExpressionValue(var7, "binding.rvList");
                var7.setAdapter((RecyclerView.Adapter)adapter);
            }

            public void onFailure(@NotNull Call call, @NotNull Throwable t) {
                Intrinsics.checkNotNullParameter(call, "call");
                Intrinsics.checkNotNullParameter(t, "t");
                ProgressBar var10000 = HomeFragment.this.getBinding().progressBar;
                Intrinsics.checkNotNullExpressionValue(var10000, "binding.progressBar");
                var10000.setVisibility(8);
                Log.e("Login Error", String.valueOf(t.getMessage()));
                Toast.makeText(HomeFragment.this.getContext(), (CharSequence)"Internet Connection Error", 1).show();
            }
        }));
    }

    public void onDestroyView() {
        super.onDestroyView();
        this._binding = null;
        this._$_clearFindViewByIdCache();
    }
}
