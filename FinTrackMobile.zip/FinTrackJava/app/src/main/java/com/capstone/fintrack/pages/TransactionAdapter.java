package com.capstone.fintrack.pages;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.capstone.fintrack.todelete.models.Account;
import com.capstone.fintrack.todelete.models.Category;
import com.capstone.fintrack.todelete.models.Record;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@Metadata(
        mv = {1, 6, 0},
        k = 1,
        d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0013B\u001d\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\u0002\u0010\bJ\b\u0010\t\u001a\u00020\nH\u0016J\u0018\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u00022\u0006\u0010\u000e\u001a\u00020\nH\u0016J\u0018\u0010\u000f\u001a\u00020\u00022\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\nH\u0016R\u0010\u0010\u0003\u001a\u0004\u0018\u00010\u0004X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0014"},
        d2 = {"Lcom/capstone/fintrack/todelete/ui/transactions/TransactionAdapter;", "Landroidx/recyclerview/widget/RecyclerView$Adapter;", "Lcom/capstone/fintrack/todelete/ui/transactions/TransactionAdapter$ViewHolder;", "context", "Landroid/content/Context;", "mList", "", "Lcom/capstone/fintrack/todelete/models/Record;", "(Landroid/content/Context;Ljava/util/List;)V", "getItemCount", "", "onBindViewHolder", "", "holder", "position", "onCreateViewHolder", "parent", "Landroid/view/ViewGroup;", "viewType", "ViewHolder", "app_debug"}
)
public final class TransactionAdapter extends RecyclerView.Adapter {
    private Context context;
    private final List mList;

    @NotNull
    public ViewHolder onCreateViewHolder(@NotNull ViewGroup parent, int viewType) {
        Intrinsics.checkNotNullParameter(parent, "parent");
        View view = LayoutInflater.from(parent.getContext()).inflate(2131492934, parent, false);
        Intrinsics.checkNotNullExpressionValue(view, "view");
        return new ViewHolder(view);
    }

    // $FF: synthetic method
    // $FF: bridge method
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup var1, int var2) {
        return (RecyclerView.ViewHolder)this.onCreateViewHolder(var1, var2);
    }

    public void onBindViewHolder(@NotNull ViewHolder holder, int position) {
        Intrinsics.checkNotNullParameter(holder, "holder");
        Record item = (Record)this.mList.get(position);
        holder.getAmount().setText((CharSequence)String.valueOf(item.getAmount()));
        holder.getType().setText((CharSequence)item.getType());
        TextView var10000 = holder.getAccount();
        Account var10001 = item.getAccount();
        Intrinsics.checkNotNull(var10001);
        var10000.setText((CharSequence)var10001.getName());
        var10000 = holder.getCategory();
        Category var4 = item.getCategory();
        Intrinsics.checkNotNull(var4);
        var10000.setText((CharSequence)var4.getName());
        holder.getDate().setText((CharSequence)item.getDateAdded());
    }

    // $FF: synthetic method
    // $FF: bridge method
    public void onBindViewHolder(RecyclerView.ViewHolder var1, int var2) {
        this.onBindViewHolder((ViewHolder)var1, var2);
    }

    public int getItemCount() {
        return this.mList.size();
    }

    public TransactionAdapter(@Nullable Context context, @NotNull List mList) {
        Intrinsics.checkNotNullParameter(mList, "mList");
        super();
        this.context = context;
        this.mList = mList;
    }

    @Metadata(
            mv = {1, 6, 0},
            k = 1,
            d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\r\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0002\u0010\u0004R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\bR\u0011\u0010\u000b\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\bR\u0011\u0010\r\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\bR\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0013\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\b¨\u0006\u0015"},
            d2 = {"Lcom/capstone/fintrack/todelete/ui/transactions/TransactionAdapter$ViewHolder;", "Landroidx/recyclerview/widget/RecyclerView$ViewHolder;", "ItemView", "Landroid/view/View;", "(Landroid/view/View;)V", "account", "Landroid/widget/TextView;", "getAccount", "()Landroid/widget/TextView;", "amount", "getAmount", "category", "getCategory", "date", "getDate", "item", "Landroid/widget/LinearLayout;", "getItem", "()Landroid/widget/LinearLayout;", "type", "getType", "app_debug"}
    )
    public static final class ViewHolder extends RecyclerView.ViewHolder {
        @NotNull
        private final TextView amount;
        @NotNull
        private final TextView type;
        @NotNull
        private final TextView account;
        @NotNull
        private final TextView category;
        @NotNull
        private final TextView date;
        @NotNull
        private final LinearLayout item;

        @NotNull
        public final TextView getAmount() {
            return this.amount;
        }

        @NotNull
        public final TextView getType() {
            return this.type;
        }

        @NotNull
        public final TextView getAccount() {
            return this.account;
        }

        @NotNull
        public final TextView getCategory() {
            return this.category;
        }

        @NotNull
        public final TextView getDate() {
            return this.date;
        }

        @NotNull
        public final LinearLayout getItem() {
            return this.item;
        }

        public ViewHolder(@NotNull View ItemView) {
            Intrinsics.checkNotNullParameter(ItemView, "ItemView");
            super(ItemView);
            View var10001 = this.itemView.findViewById(2131296794);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvAmount)");
            this.amount = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296814);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvType)");
            this.type = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296793);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvAccount)");
            this.account = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296797);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvCategory)");
            this.category = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296798);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.tvDate)");
            this.date = (TextView)var10001;
            var10001 = this.itemView.findViewById(2131296538);
            Intrinsics.checkNotNullExpressionValue(var10001, "itemView.findViewById(R.id.llItem)");
            this.item = (LinearLayout)var10001;
        }
    }
}
