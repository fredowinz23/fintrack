package com.capstone.fintrack.todelete.api

import com.capstone.fintrack.todelete.auth.LoginInfo
import com.capstone.fintrack.todelete.request.HomeDataRequest
import com.capstone.fintrack.todelete.request.TransactionRequest
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Headers


interface ApiInterface {
    @Headers("Content-Type: application/json")
    @POST("api/login.php")
    fun loginUser(@Body loginInfo: LoginInfo): Call<LoginInfo>

    @Headers("Content-Type: application/json")
    @POST("api/get-home-data.php")
    fun getHomeData(@Body homeDataRequest: HomeDataRequest): Call<HomeDataRequest>

    @Headers("Content-Type: application/json")
    @POST("api/get-transactions.php")
    fun getTransactions(@Body transactionRequest: TransactionRequest): Call<TransactionRequest>


}