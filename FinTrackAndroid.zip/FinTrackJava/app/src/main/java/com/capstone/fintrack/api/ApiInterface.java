package com.capstone.fintrack.api;

import com.capstone.fintrack.todelete.auth.LoginInfo;
import com.capstone.fintrack.todelete.request.HomeDataRequest;
import com.capstone.fintrack.todelete.request.TransactionRequest;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface ApiInterface {
    @Headers({"Content-Type: application/json"})
    @POST("api/login.php")
    @NotNull
    Call loginUser(@Body @NotNull LoginInfo var1);

    @Headers({"Content-Type: application/json"})
    @POST("api/get-home-data.php")
    @NotNull
    Call getHomeData(@Body @NotNull HomeDataRequest var1);

    @Headers({"Content-Type: application/json"})
    @POST("api/get-transactions.php")
    @NotNull
    Call getTransactions(@Body @NotNull TransactionRequest var1);
}