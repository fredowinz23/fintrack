package com.capstone.fintrack;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.capstone.fintrack.todelete.MainActivity;
import com.capstone.fintrack.todelete.api.UserSession;
import com.capstone.fintrack.todelete.auth.LoginActivity;

import org.jetbrains.annotations.Nullable;

import kotlin.text.StringsKt;

@SuppressLint({"CustomSplashScreen"})
public final class SplashScreenActivity extends AppCompatActivity {
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final UserSession userSession = new UserSession((Context)this);
        (new Handler(Looper.getMainLooper())).postDelayed((Runnable)(new Runnable() {
            public final void run() {
                CharSequence var1 = (CharSequence)userSession.getUsername();
                if (var1 == null || StringsKt.isBlank(var1)) {
                    startActivity(new Intent(SplashScreenActivity.this, LoginActivity.class));
                } else {
                    startActivity(new Intent(SplashScreenActivity.this, MainActivity.class));
                }

                finish();
            }
        }), 2000L);
    }
}
